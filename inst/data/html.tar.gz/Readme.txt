Run "run.sh" in the console, or use the following command:
"python -m SimpleHTTPServer" or "python3 -m http.server", 
then navigate to http://localhost:8000/ in your internet browser to see the results. 